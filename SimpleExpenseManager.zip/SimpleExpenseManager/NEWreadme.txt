There was an issue when trying to push to github.
To resolve it it asked to pull first. 
Yet the problem did not get resolved. 
Therefore this is a just a zip of the project after being pulled.
Since many have successfully submitted the assignment I did not post it in the forum.